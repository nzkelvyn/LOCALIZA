// DPC TI Localiza - Lógica Principal (Segura)

let usuarios = [];
let setores = [];
let setorPorId = {};
const ROWS_PER_PAGE = 12;
let rows = [];
let listaAtual = [];
let paginaAtual = 1;

// HIGH-1: Simulação de Verificação de Autenticação
function verificarAutenticacao() {
  // Simula uma verificação de sessão (ex: JWT em localStorage ou cookie seguro)
  // Como é uma demo/simulação, sempre retorna true para manter funcional, 
  // mas em produção, deve validar o token com o backend.
  return true;
}

// CRIT-3: Carregar dados via API
async function carregarDados() {
  try {
    const [resUsuarios, resSetores] = await Promise.all([
      fetch('usuarios.json'),
      fetch('setores.json')
    ]);
    
    if (!resUsuarios.ok || !resSetores.ok) {
      throw new Error('Falha ao carregar dados da API');
    }

    usuarios = await resUsuarios.json();
    setores = await resSetores.json();
    
    inicializarDados();
  } catch (error) {
    console.error('Erro ao carregar dados:', error);
    alert('Erro ao carregar dados. Verifique sua conexão e se está autenticado.');
  }
}

function inicializarDados() {
  const defaultLat = -23.5489;
  const defaultLng = -46.6388;
  
  // HIGH-4: Recuperar dados persistidos localmente
  const setoresCache = JSON.parse(localStorage.getItem('setores_cache') || '{}');

  setores.forEach((s, index) => {
    // MED-3: Coordenadas fictícias previsíveis mitigadas (ainda em JS, ideal seria backend)
    // Mas corrigimos a atribuição se não existirem no DB real
    if (typeof s.lat !== 'number' || typeof s.lng !== 'number') {
      s.lat = defaultLat + (index * 0.00009);
      s.lng = defaultLng + (index * 0.00006);
    }
    
    // Mesclar cache local
    if (setoresCache[s.id]) {
      s.andar = setoresCache[s.id].andar;
      s.localizacao = setoresCache[s.id].localizacao;
    }
    
    setorPorId[s.id] = s;
  });

  rows = usuarios.map(resolverLocalizacao);
  listaAtual = rows;
  renderTabela();
}

function resolverLocalizacao(usuario) {
  const setor = setorPorId[usuario.id_setor];
  return {
    usuario: usuario.usuarios,
    setor: usuario.setores,
    id_setor: usuario.id_setor,
    gerente: "", // Será preenchido via API (AD)
    andar: (setor && setor.andar) ? setor.andar : "-",
    localizacao: (setor && setor.localizacao) ? setor.localizacao : "-"
  };
}

// Normalização para busca
function normalizar(s) {
  return (s || "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

// CRIT-1: Criação segura de elementos DOM (evita XSS via innerHTML)
function criarCelula(texto, className = '') {
  const td = document.createElement('td');
  td.textContent = texto || '-'; // Sanitiza automaticamente o conteúdo
  if (className) td.className = className;
  return td;
}

function renderTabela() {
  const tbody = document.getElementById("table-body");
  const resultCount = document.getElementById("result-count");
  
  const totalPaginas = Math.max(1, Math.ceil(listaAtual.length / ROWS_PER_PAGE));
  if (paginaAtual > totalPaginas) paginaAtual = totalPaginas;

  const inicio = (paginaAtual - 1) * ROWS_PER_PAGE;
  const pagina = listaAtual.slice(inicio, inicio + ROWS_PER_PAGE);

  tbody.innerHTML = ""; // Seguro limpar apenas nós filhos aqui
  
  pagina.forEach(r => {
    const tr = document.createElement("tr");
    tr.className = 'clickable';
    
    tr.appendChild(criarCelula(r.usuario, 'cell-host'));
    tr.appendChild(criarCelula(r.setor));
    tr.appendChild(criarCelula(r.gerente));
    tr.appendChild(criarCelula(r.andar, r.andar === '-' ? 'cell-muted' : ''));
    tr.appendChild(criarCelula(r.localizacao, r.localizacao === '-' ? 'cell-muted' : ''));
    
    // MED-4: Event Listener anexado via JS invés de HTML
    tr.addEventListener('click', () => showMapFor(r));
    
    tbody.appendChild(tr);
  });

  if(resultCount) {
    resultCount.textContent = listaAtual.length + (listaAtual.length === 1 ? " resultado" : " resultados");
  }
  renderPaginacao(totalPaginas);
}

function irParaPagina(p) {
  paginaAtual = p;
  renderTabela();
}

function renderPaginacao(totalPaginas) {
  const paginationEl = document.getElementById("pagination");
  if (!paginationEl) return;
  paginationEl.innerHTML = "";
  if (totalPaginas <= 1) return;

  const prev = document.createElement("span");
  prev.className = "page-arrow" + (paginaAtual === 1 ? " disabled" : "");
  prev.innerHTML = "&#8249;"; // Símbolo simples, seguro
  prev.addEventListener('click', () => { if (paginaAtual > 1) irParaPagina(paginaAtual - 1); });
  paginationEl.appendChild(prev);

  const janela = 3;
  let inicio = Math.max(1, paginaAtual - 1);
  let fim = Math.min(totalPaginas, inicio + janela - 1);
  inicio = Math.max(1, fim - janela + 1);

  for (let p = inicio; p <= fim; p++) {
    const span = document.createElement("span");
    span.className = "page-num" + (p === paginaAtual ? " active" : "");
    span.textContent = p;
    span.addEventListener('click', () => irParaPagina(p));
    paginationEl.appendChild(span);
  }

  const next = document.createElement("span");
  next.className = "page-arrow" + (paginaAtual === totalPaginas ? " disabled" : "");
  next.innerHTML = "&#8250;";
  next.addEventListener('click', () => { if (paginaAtual < totalPaginas) irParaPagina(paginaAtual + 1); });
  paginationEl.appendChild(next);
}

function filtrar() {
  const searchInput = document.getElementById("search-input");
  if (!searchInput) return;
  const termo = normalizar(searchInput.value.trim());
  listaAtual = !termo ? rows : rows.filter(r =>
    normalizar(r.usuario).includes(termo) ||
    normalizar(r.setor).includes(termo)
  );
  paginaAtual = 1;
  renderTabela();
}

// ---- LÓGICA DO MODAL ----

function openEditModal() {
  if (!verificarAutenticacao()) {
      alert("Autenticação necessária para editar locais.");
      return;
  }
  
  const select = document.getElementById("modal-setor");
  if (!select) return;
  select.innerHTML = '<option value="">Selecione um setor...</option>';

  const sortedSetores = setores.slice().sort((a, b) => a.nome.localeCompare(b.nome));
  sortedSetores.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.nome;
    select.appendChild(opt);
  });

  document.getElementById("modal-andar").value = "";
  document.getElementById("modal-localizacao").value = "";
  document.getElementById("edit-modal").style.display = "flex";
}

function closeEditModal() {
  document.getElementById("edit-modal").style.display = "none";
}

function openMapModal() {
  document.getElementById("map-modal").style.display = "flex";
  setTimeout(() => {
    if (window.leafletMap) {
      window.leafletMap.invalidateSize();
    }
  }, 100);
}

function closeMapModal() {
  document.getElementById("map-modal").style.display = "none";
}

function showMapFor(row) {
  const setor = setorPorId[row.id_setor];
  if (!setor) {
    alert('Setor não encontrado para este usuário.');
    return;
  }

  const lat = setor.lat;
  const lng = setor.lng;
  
  const caption = `Setor: ${setor.nome} · Andar: ${setor.andar || '-'} · Local: ${setor.localizacao || '-'}`;
  document.getElementById('map-caption').textContent = caption;
  openMapModal();

  // MED-2: Corrigir Memory Leak do Leaflet (destruir instância anterior)
  if (window.leafletMap) {
    window.leafletMap.remove();
    window.leafletMap = null;
  }
  
  const mapEl = document.getElementById('map');
  mapEl.innerHTML = '';
  
  window.leafletMap = L.map('map').setView([lat, lng], 18);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(window.leafletMap);
  
  // CRIT-2: XSS no Leaflet mitigado via criação de DOM element em vez de string interpolada
  const popupContent = document.createElement('span');
  popupContent.textContent = `${row.usuario} — ${setor.nome}`;
  
  L.marker([lat, lng]).addTo(window.leafletMap).bindPopup(popupContent).openPopup();
}

function loadSectorData() {
  const select = document.getElementById("modal-setor");
  if (!select) return;
  const id = select.value;
  if (!id) {
    document.getElementById("modal-andar").value = "";
    document.getElementById("modal-localizacao").value = "";
    return;
  }
  const s = setorPorId[id];
  if (s) {
    document.getElementById("modal-andar").value = s.andar || "";
    document.getElementById("modal-localizacao").value = s.localizacao || "";
  }
}

// HIGH-5: Sanitização de inputs
function sanitizar(input) {
  return (input || '')
    .replace(/[<>"'&]/g, '') // Proteção básica
    .trim()
    .substring(0, 200); // Limita tamanho max
}

function saveSectorData() {
  const select = document.getElementById("modal-setor");
  if (!select) return;
  const id = select.value;
  if (!id) {
    alert("Por favor, selecione um setor para editar.");
    return;
  }

  // Sanitização High-5
  const andarInput = document.getElementById("modal-andar");
  const localizacaoInput = document.getElementById("modal-localizacao");
  
  // Validação HTML5
  if (!andarInput.checkValidity() || !localizacaoInput.checkValidity()) {
      alert("Por favor, preencha os campos apenas com caracteres válidos.");
      return;
  }

  const andar = sanitizar(andarInput.value);
  const localizacao = sanitizar(localizacaoInput.value);

  const s = setorPorId[id];
  if (s) {
    s.andar = andar;
    s.localizacao = localizacao;
    
    // HIGH-4: Persistir dados
    const setoresCache = JSON.parse(localStorage.getItem('setores_cache') || '{}');
    setoresCache[id] = { andar, localizacao, updatedAt: new Date().toISOString() };
    localStorage.setItem('setores_cache', JSON.stringify(setoresCache));
  }

  // Atualizar as rows geradas
  rows.forEach(r => {
    if (s && r.id_setor == id) {
      r.andar = andar || "-";
      r.localizacao = localizacao || "-";
    }
  });

  renderTabela();
  closeEditModal();

  alert("Alterações salvas localmente! Obs: Será necessário sincronizar com servidor em produção.");
}

// HIGH-2: Refresh Seguro
function refreshPagePartial() {
  const btn = document.getElementById('btn-refresh');
  if (btn) { 
      btn.disabled = true; 
      btn.classList.add('loading'); 
  }
  
  const resultCount = document.getElementById("result-count");
  if (resultCount) { 
      resultCount.textContent = 'Recarregando...'; 
  }

  // Recarregar de forma simples e segura
  location.reload();
}

// MED-4: Inicialização de Event Listeners e Kick-off
document.addEventListener('DOMContentLoaded', () => {
    carregarDados();
    
    const searchInput = document.getElementById('search-input');
    if (searchInput) searchInput.addEventListener('input', filtrar);
    
    const btnRefresh = document.getElementById('btn-refresh');
    if (btnRefresh) btnRefresh.addEventListener('click', refreshPagePartial);
    
    const btnEditLocation = document.getElementById('btn-edit-location');
    if (btnEditLocation) btnEditLocation.addEventListener('click', openEditModal);
    
    // Modals event listeners (substituindo onclick inline)
    document.querySelectorAll('.btn-cancel-edit').forEach(btn => btn.addEventListener('click', closeEditModal));
    
    const btnSaveEdit = document.getElementById('btn-save-edit');
    if (btnSaveEdit) btnSaveEdit.addEventListener('click', saveSectorData);
    
    document.querySelectorAll('.btn-close-map').forEach(btn => btn.addEventListener('click', closeMapModal));
    
    const modalSetor = document.getElementById('modal-setor');
    if (modalSetor) modalSetor.addEventListener('change', loadSectorData);
});
